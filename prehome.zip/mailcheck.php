<?php
$sub="mail checking in php xampp";
$msg="successfully sent mail is this.Hii iam from xampp";
$rec="bhanuprakashbobba833@gmail.com";
mail($rec,$sub,$msg);
?>