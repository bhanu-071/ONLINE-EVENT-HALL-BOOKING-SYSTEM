<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
$host = "localhost";  
$user = "root";  
$pass = "";
$db="eventhall";  
$conn = mysqli_connect($host,$user,$pass,$db);  
if($conn )  
{ }
else{
   die('Could not connect: ' . mysqli_connect_error());  
}
session_start();
$email=$_SESSION['username'];  
$purpose=$_POST['purpose'];
$details=$_POST['usertype'];
$tickets=$_POST['offline'];
if($purpose=='cancellation'){
$sql = "select * from events where emailid='$email'";
$result=mysqli_query($conn,$sql);
if (mysqli_num_rows($result) > 0) {
$flag=0;
while($ata = mysqli_fetch_assoc($result)) {
   $al=$ata['eventname']." from ".$ata['fromdate']." to ".$ata['todate']." in ".$ata['halldetails'];
if($al==$details){
$a=$ata['halldetails'];
$b=$ata['fromdate'];
$c=$ata['todate'];
  $onlin=$ata['onlinetickets'];
  if($onlin==0 || $onlin=='NA'){
  $flag=1;
 $asql="delete from events where emailid='$email' and halldetails='$a' and fromdate='$b' and todate='$c'";
$res=mysqli_query($conn,$asql);
$wsql = "select * from hallsavailaccdate where fromdate='$b'";
$wresult=mysqli_query($conn,$wsql);
if (mysqli_num_rows($wresult) > 0) {
while($wata = mysqli_fetch_assoc($wresult)) {
$hdet=$wata['hallname'].",".$wata['halladdress'];
if($hdet==$a){
$zsql="delete from hallsavailaccdate where fromdate='$b' and todate='$c'";
$zres=mysqli_query($conn,$zsql);}}}
if($flag==1){
echo "<b>cancelled succussfully!</b>";

require 'vendor/autoload.php';
  
try {
$mail = new PHPMailer;
 $mail->isSMTP(); 
$mail->Host= 'smtp.gmail.com';
    $mail->SMTPDebug = 0;  
    $mail->SMTPAuth   = true;                             
    $mail->Username   = 'bhanuprakashbobba833@gmail.com';                 
    $mail->Password   = 'wyjiwhpsrpjnegni';                        
    $mail->SMTPSecure = 'TLS';                              
    $mail->Port       = 587; 
  $mail->Port       = 587; 
$mail->SMTPSecure = '';
$mail->smtpConnect([
    'ssl' => [
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    ]
]);
    $mail->setFrom('bhanuprakashbobba833@gmail.com', 'VEDHIKA');           
    $mail->addAddress($email);
    $mail->isHTML(true);                                  
    $mail->Subject = 'YOUR EVENT IS CANCELLED!';
    $mail->Body    = "<b>Hello! Organiser,your event ".$details." is cancelled successfully from VEDHIKA website.</b>";
    $mail->AltBody = 'mesg from admin eventhall';
    $mail->send();
    echo "Mail has been sent successfully!";

$mail->smtpClose(); 
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
 
}break;}}
if($flag==0){
echo "<b>cancellation not allowed as participants book tickets of this event.</b>";}
}}}

else if($purpose=='offlineticketsupdation'){
$sql = "select * from events where emailid='$email'";
$result=mysqli_query($conn,$sql);
if (mysqli_num_rows($result) > 0) {
$flag=0;
while($ata = mysqli_fetch_assoc($result)) {
   $al=$ata['eventname']." from ".$ata['fromdate']." to ".$ata['todate']." in ".$ata['halldetails'];
if($al==$details && $ata['eventtype']=='Professional'){
$flag=1;
$cap=$ata['capacity'];
if($tickets==1){
$s="Issue seat ".$cap;
$cap=$cap-1;}
else if($tickets<=0){
$s="you are not enter no of tickets correctly!"; }
else{
$s="Issue seat ".$cap."- seat ";
$cap=$cap-$tickets;
$cap=$cap++;
$s=$s.$cap;
$cap=$cap-1;}
$halldeta=$ata['halldetails'];
$fdate=$ata['fromdate'];
$tickets=$ata['offlinetickets']+$tickets;
$psql="UPDATE events SET capacity='$cap',offlinetickets='$tickets' where eventtype='Professional' and halldetails='$halldeta' and fromdate='$fdate'";
mysqli_query($conn,$psql);
echo "<b>$s</b>";
}}
if($flag==0){
echo "<b>As it is Non Professional event there are no tickets.so tickets updation is not possible.</b>";}}}
mysqli_close($conn);
?>