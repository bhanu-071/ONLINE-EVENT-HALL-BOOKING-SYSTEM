<?php
	$firstname = $_POST['firstname'];
        $middlename = $_POST['middlename'];
	$lastname = $_POST['lastname'];
	$phonenum = $_POST['phonenum'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$confirmpassword = $_POST['confirmpassword'];
        $address=$_POST['address'];

	// Database connection
	$conn = new mysqli('localhost','root','','eventhall');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into organiser(firstname, middlename, lastname, phonenum, email, password, confirmpassword, address) values(?, ?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("sssssi", $firstname, $middlename, $lastname, $gender, $email, $password, $confirmpassword,$address);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registration successfully...";
		$stmt->close();
		$conn->close();
	}
?>



