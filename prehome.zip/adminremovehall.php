<?php  
$hallname=$_POST["hallname"];
$capacity=$_POST["capacity"];
$email=$_POST["email"];
$address=$_POST["address"];
$host = "localhost";  
$user = "root";  
$pass = "";
$db="eventhall";  
$conn = mysqli_connect($host,$user,$pass,$db);  
if($conn)  
{  
   
}
else{
   die('Could not connect: ' . mysqli_connect_error());  
}  
$sql="DELETE FROM bookinghalls where emailid='$email' AND address='$address' AND hallname
='$hallname'";
$data=mysqli_query($conn,$sql);
if($data)
{echo "data deleted succussfully!";}
mysqli_close($conn);
?>