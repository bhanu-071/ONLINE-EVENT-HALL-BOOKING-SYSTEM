<?php  
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
$email=$_POST["email"];  
$username=$_POST["usertype"];
$host = "localhost";  
$user = "root";  
$pass = "";
$db="eventhall";  
$conn = mysqli_connect($host,$user,$pass,$db);  
if($conn)  
{  
   
}
else{
   die('Could not connect: ' . mysqli_connect_error());  
}  
switch ($username) {
  case "organiser":
    $sql = 'select * from organiser'; 
    break;
  case "owner":
    $sql = 'select * from owner'; 
    break;
  case "participant":
    $sql = 'select * from participant'; 
    break;} 
$retval=mysqli_query($conn,$sql);  
  $i=0;
if(mysqli_num_rows($retval) > 0){  
 while($row = mysqli_fetch_assoc($retval)){  
   if($email==$row['email']){
      
      $i++;
      $name=$row['firstname']." ".$row['middlename']." ".$row['lastname'];
      $phno=$row['phonenum'];
      $addr=$row['address'];
}}

$inssql="INSERT INTO blockusers(name,Emailid,phonenum,usertype,address) values(
'$name','$email','$phno','$username','$addr')";
$block=mysqli_query($conn,$inssql);
if($block)
{echo "user blocked successfully!";

require 'vendor/autoload.php';
  
try {
$mail = new PHPMailer;
 $mail->isSMTP(); 
$mail->Host= 'smtp.gmail.com';
    $mail->SMTPDebug = 0;  
    $mail->SMTPAuth   = true;                             
    $mail->Username   = 'bhanuprakashbobba833@gmail.com';                 
    $mail->Password   = 'wyjiwhpsrpjnegni';                        
    $mail->SMTPSecure = 'TLS';                              
    $mail->Port       = 587; 
  $mail->Port       = 587; 
$mail->SMTPSecure = '';
$mail->smtpConnect([
    'ssl' => [
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    ]
]);
    $mail->setFrom('bhanuprakashbobba833@gmail.com', 'VEDHIKA');           
    $mail->addAddress($email);
    $mail->isHTML(true);                                  
    $mail->Subject = 'YOUR ARE BLOCKED FROM NOW!';
    $mail->Body    = "<b>Hello! ".$username." You are blocked and not able to do any operations.To unblock contact admin from VEDHIKA website.</b>";
    $mail->AltBody = 'mesg from admin eventhall';
    $mail->send();
    echo "Mail has been sent successfully!";

$mail->smtpClose(); 
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
}}
else{echo "user is not exist in $username";}
